export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: 'dress' | 'jewelry' | 'beauty';
  subcategory: string;
  rating: number;
  reviews: number;
  inStock: boolean;
  isNew?: boolean;
  isBestseller?: boolean;
  colors?: string[];
  sizes?: string[];
}

export const products: Product[] = [
  // DRESSES - 15 Products
  {
    id: 'dress-1',
    name: 'Champagne Satin Slip Dress',
    description: 'Elegant champagne gold satin slip dress with cowl neckline. Perfect for evening events and special occasions. Made with premium silk-blend fabric.',
    price: 4999,
    originalPrice: 6999,
    image: '/images/dress-1.jpg',
    category: 'dress',
    subcategory: 'evening',
    rating: 4.8,
    reviews: 234,
    inStock: true,
    isNew: true,
    colors: ['Champagne', 'Black', 'Blush'],
    sizes: ['XS', 'S', 'M', 'L', 'XL']
  },
  {
    id: 'dress-2',
    name: 'Powder Pink Blazer Dress',
    description: 'Trendy oversized blazer dress in powder pink with self-tie belt. Modern power dressing for the confident woman.',
    price: 3999,
    originalPrice: 5499,
    image: '/images/dress-2.jpg',
    category: 'dress',
    subcategory: 'workwear',
    rating: 4.7,
    reviews: 189,
    inStock: true,
    isBestseller: true,
    colors: ['Pink', 'Navy', 'Black'],
    sizes: ['S', 'M', 'L', 'XL']
  },
  {
    id: 'dress-3',
    name: 'Emerald Silk Wrap Dress',
    description: 'Stunning emerald green silk wrap dress with flowing silhouette. Elegant cocktail attire that turns heads.',
    price: 5999,
    originalPrice: 7999,
    image: '/images/dress-3.jpg',
    category: 'dress',
    subcategory: 'cocktail',
    rating: 4.9,
    reviews: 312,
    inStock: true,
    colors: ['Emerald', 'Ruby', 'Sapphire'],
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL']
  },
  {
    id: 'dress-4',
    name: 'Dusty Rose Puff Sleeve Dress',
    description: 'Romantic midi dress with puff sleeves in dusty rose. Feminine and flattering for any occasion.',
    price: 3499,
    originalPrice: 4499,
    image: '/images/dress-4.jpg',
    category: 'dress',
    subcategory: 'casual',
    rating: 4.6,
    reviews: 278,
    inStock: true,
    isNew: true,
    colors: ['Rose', 'Lavender', 'Mint'],
    sizes: ['XS', 'S', 'M', 'L', 'XL']
  },
  {
    id: 'dress-5',
    name: 'Classic Black Bodycon Dress',
    description: 'Sleek black bodycon dress that hugs your curves perfectly. A wardrobe essential for every woman.',
    price: 2999,
    originalPrice: 3999,
    image: '/images/dress-5.jpg',
    category: 'dress',
    subcategory: 'evening',
    rating: 4.8,
    reviews: 456,
    inStock: true,
    isBestseller: true,
    colors: ['Black', 'Red', 'White'],
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL']
  },
  {
    id: 'dress-6',
    name: 'Navy Shirt Dress',
    description: 'Sophisticated navy shirt dress with belt. Perfect for office to evening transitions.',
    price: 3299,
    originalPrice: 4299,
    image: '/images/dress-6.jpg',
    category: 'dress',
    subcategory: 'workwear',
    rating: 4.5,
    reviews: 198,
    inStock: true,
    colors: ['Navy', 'White', 'Khaki'],
    sizes: ['S', 'M', 'L', 'XL']
  },
  {
    id: 'dress-7',
    name: 'Burgundy Cut-Out Maxi Dress',
    description: 'Dramatic burgundy maxi dress with cut-out details and side slit. Perfect for red carpet moments.',
    price: 6999,
    originalPrice: 8999,
    image: '/images/dress-7.jpg',
    category: 'dress',
    subcategory: 'evening',
    rating: 4.9,
    reviews: 156,
    inStock: true,
    isNew: true,
    colors: ['Burgundy', 'Black', 'Navy'],
    sizes: ['XS', 'S', 'M', 'L', 'XL']
  },
  {
    id: 'dress-8',
    name: 'Lavender Pleated Midi Dress',
    description: 'Elegant pleated midi dress in soft lavender. Flowy and comfortable for all-day wear.',
    price: 3799,
    originalPrice: 4999,
    image: '/images/dress-8.jpg',
    category: 'dress',
    subcategory: 'casual',
    rating: 4.7,
    reviews: 234,
    inStock: true,
    colors: ['Lavender', 'Peach', 'Mint'],
    sizes: ['XS', 'S', 'M', 'L', 'XL']
  },
  {
    id: 'dress-9',
    name: 'Cream Ribbed Knit Dress',
    description: 'Cozy ribbed knit dress in cream beige. Perfect for casual outings and coffee dates.',
    price: 2499,
    originalPrice: 3499,
    image: '/images/dress-9.jpg',
    category: 'dress',
    subcategory: 'casual',
    rating: 4.6,
    reviews: 312,
    inStock: true,
    colors: ['Cream', 'Grey', 'Black'],
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL']
  },
  {
    id: 'dress-10',
    name: 'Coral One-Shoulder Dress',
    description: 'Stunning one-shoulder asymmetric dress in coral orange. Modern and chic for any celebration.',
    price: 4499,
    originalPrice: 5999,
    image: '/images/dress-10.jpg',
    category: 'dress',
    subcategory: 'cocktail',
    rating: 4.8,
    reviews: 189,
    inStock: true,
    isNew: true,
    colors: ['Coral', 'Pink', 'Red'],
    sizes: ['XS', 'S', 'M', 'L', 'XL']
  },
  {
    id: 'dress-11',
    name: 'Peach Tiered Ruffle Maxi',
    description: 'Bohemian-inspired tiered ruffle maxi dress in soft peach. Perfect for beach weddings and summer parties.',
    price: 4299,
    originalPrice: 5499,
    image: '/images/dress-11.jpg',
    category: 'dress',
    subcategory: 'boho',
    rating: 4.7,
    reviews: 267,
    inStock: true,
    colors: ['Peach', 'White', 'Yellow'],
    sizes: ['XS', 'S', 'M', 'L', 'XL']
  },
  {
    id: 'dress-12',
    name: 'Silver Sequin Mini Dress',
    description: 'Glamorous silver sequin mini dress for unforgettable party nights. Shine bright like a diamond.',
    price: 5499,
    originalPrice: 7499,
    image: '/images/dress-12.jpg',
    category: 'dress',
    subcategory: 'party',
    rating: 4.9,
    reviews: 198,
    inStock: true,
    isBestseller: true,
    colors: ['Silver', 'Gold', 'Rose Gold'],
    sizes: ['XS', 'S', 'M', 'L']
  },
  {
    id: 'dress-13',
    name: 'White Halter Jumpsuit',
    description: 'Elegant white halter jumpsuit with wide legs. Modern sophistication for special occasions.',
    price: 4999,
    originalPrice: 6499,
    image: '/images/dress-13.jpg',
    category: 'dress',
    subcategory: 'jumpsuit',
    rating: 4.8,
    reviews: 145,
    inStock: true,
    colors: ['White', 'Black', 'Navy'],
    sizes: ['XS', 'S', 'M', 'L', 'XL']
  },
  {
    id: 'dress-14',
    name: 'Plum Velvet Slip Dress',
    description: 'Luxurious plum velvet slip dress with cowl neckline. Rich texture for winter celebrations.',
    price: 5799,
    originalPrice: 7499,
    image: '/images/dress-14.jpg',
    category: 'dress',
    subcategory: 'evening',
    rating: 4.7,
    reviews: 178,
    inStock: true,
    isNew: true,
    colors: ['Plum', 'Emerald', 'Burgundy'],
    sizes: ['XS', 'S', 'M', 'L', 'XL']
  },
  {
    id: 'dress-15',
    name: 'Navy Polka Dot Dress',
    description: 'Classic navy polka dot midi dress with belt. Timeless elegance never goes out of style.',
    price: 3299,
    originalPrice: 4299,
    image: '/images/dress-15.jpg',
    category: 'dress',
    subcategory: 'vintage',
    rating: 4.6,
    reviews: 289,
    inStock: true,
    colors: ['Navy', 'Red', 'Black'],
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL']
  },

  // JEWELRY - 12 Products
  {
    id: 'jewelry-1',
    name: 'Diamond Tennis Bracelet',
    description: 'Exquisite diamond tennis bracelet in white gold setting. Timeless luxury for every occasion.',
    price: 89999,
    originalPrice: 119999,
    image: '/images/jewelry-1.jpg',
    category: 'jewelry',
    subcategory: 'bracelet',
    rating: 5.0,
    reviews: 89,
    inStock: true,
    isBestseller: true,
    colors: ['White Gold', 'Yellow Gold', 'Rose Gold']
  },
  {
    id: 'jewelry-2',
    name: 'Gold Pearl Hoop Earrings',
    description: 'Elegant gold hoop earrings with freshwater pearl drops. Modern meets classic beautifully.',
    price: 4999,
    originalPrice: 6999,
    image: '/images/jewelry-2.jpg',
    category: 'jewelry',
    subcategory: 'earrings',
    rating: 4.8,
    reviews: 234,
    inStock: true,
    isNew: true,
    colors: ['Gold', 'Silver']
  },
  {
    id: 'jewelry-3',
    name: 'Sapphire Halo Ring',
    description: 'Stunning sapphire ring with diamond halo in platinum setting. A piece to treasure forever.',
    price: 45999,
    originalPrice: 59999,
    image: '/images/jewelry-3.jpg',
    category: 'jewelry',
    subcategory: 'ring',
    rating: 4.9,
    reviews: 67,
    inStock: true,
    colors: ['Platinum', 'White Gold']
  },
  {
    id: 'jewelry-4',
    name: 'Gold Heart Pendant Necklace',
    description: 'Delicate gold chain with dainty heart pendant. Perfect for everyday wear or layering.',
    price: 2999,
    originalPrice: 3999,
    image: '/images/jewelry-4.jpg',
    category: 'jewelry',
    subcategory: 'necklace',
    rating: 4.7,
    reviews: 456,
    inStock: true,
    colors: ['Gold', 'Rose Gold', 'Silver']
  },
  {
    id: 'jewelry-5',
    name: 'Emerald Drop Earrings',
    description: 'Luxurious emerald drop earrings with diamond accents in gold setting. Red carpet ready.',
    price: 24999,
    originalPrice: 32999,
    image: '/images/jewelry-5.jpg',
    category: 'jewelry',
    subcategory: 'earrings',
    rating: 4.9,
    reviews: 45,
    inStock: true,
    isNew: true,
    colors: ['Gold']
  },
  {
    id: 'jewelry-6',
    name: 'Rose Gold Geometric Cuff',
    description: 'Modern geometric cuff bracelet in rose gold. Bold statement piece for the fashion-forward.',
    price: 5999,
    originalPrice: 7999,
    image: '/images/jewelry-6.jpg',
    category: 'jewelry',
    subcategory: 'bracelet',
    rating: 4.6,
    reviews: 178,
    inStock: true,
    colors: ['Rose Gold', 'Gold', 'Silver']
  },
  {
    id: 'jewelry-7',
    name: 'Classic Pearl Strand Necklace',
    description: 'Timeless pearl strand necklace with gold clasp. Elegance that transcends generations.',
    price: 12999,
    originalPrice: 16999,
    image: '/images/jewelry-7.jpg',
    category: 'jewelry',
    subcategory: 'necklace',
    rating: 4.8,
    reviews: 312,
    inStock: true,
    isBestseller: true,
    colors: ['White', 'Cream', 'Pink']
  },
  {
    id: 'jewelry-8',
    name: 'Stackable Gold Rings Set',
    description: 'Set of three stackable gold rings in different textures. Mix and match for endless styles.',
    price: 3999,
    originalPrice: 5499,
    image: '/images/jewelry-8.jpg',
    category: 'jewelry',
    subcategory: 'ring',
    rating: 4.7,
    reviews: 289,
    inStock: true,
    isNew: true,
    colors: ['Gold', 'Rose Gold', 'Silver'],
    sizes: ['5', '6', '7', '8', '9']
  },
  {
    id: 'jewelry-9',
    name: 'Amethyst Cocktail Ring',
    description: 'Bold amethyst cocktail ring in silver setting. Make a statement at your next event.',
    price: 8999,
    originalPrice: 11999,
    image: '/images/jewelry-9.jpg',
    category: 'jewelry',
    subcategory: 'ring',
    rating: 4.6,
    reviews: 156,
    inStock: true,
    colors: ['Silver'],
    sizes: ['6', '7', '8', '9']
  },
  {
    id: 'jewelry-10',
    name: 'Celestial Charm Anklet',
    description: 'Delicate gold anklet with star and moon charms. Add a touch of magic to your look.',
    price: 1999,
    originalPrice: 2999,
    image: '/images/jewelry-10.jpg',
    category: 'jewelry',
    subcategory: 'anklet',
    rating: 4.5,
    reviews: 234,
    inStock: true,
    colors: ['Gold', 'Silver']
  },
  {
    id: 'jewelry-11',
    name: 'Diamond Choker Necklace',
    description: 'Elegant diamond choker necklace in gold setting. Sophisticated glamour for special occasions.',
    price: 34999,
    originalPrice: 44999,
    image: '/images/jewelry-11.jpg',
    category: 'jewelry',
    subcategory: 'necklace',
    rating: 4.9,
    reviews: 78,
    inStock: true,
    isNew: true,
    colors: ['Gold', 'White Gold']
  },
  {
    id: 'jewelry-12',
    name: 'Crystal Drop Earrings',
    description: 'Sparkling crystal drop earrings in silver setting. Perfect for adding glamour to any outfit.',
    price: 3499,
    originalPrice: 4999,
    image: '/images/jewelry-12.jpg',
    category: 'jewelry',
    subcategory: 'earrings',
    rating: 4.7,
    reviews: 345,
    inStock: true,
    colors: ['Silver', 'Gold']
  },

  // BEAUTY ELECTRONICS - 12 Products (China Export Focus)
  {
    id: 'beauty-1',
    name: 'Pro Electric Nail Drill',
    description: 'Professional electric nail drill with 35,000 RPM and LED display. Perfect for salon-quality manicures at home.',
    price: 4999,
    originalPrice: 6999,
    image: '/images/beauty-1.jpg',
    category: 'beauty',
    subcategory: 'nail-tools',
    rating: 4.8,
    reviews: 567,
    inStock: true,
    isBestseller: true,
    colors: ['Rose Gold', 'White']
  },
  {
    id: 'beauty-2',
    name: 'UV LED Nail Lamp 120W',
    description: 'High-power UV LED nail lamp for quick gel polish curing. 4 timer settings and automatic sensor.',
    price: 2499,
    originalPrice: 3499,
    image: '/images/beauty-2.jpg',
    category: 'beauty',
    subcategory: 'nail-tools',
    rating: 4.7,
    reviews: 892,
    inStock: true,
    colors: ['White', 'Pink']
  },
  {
    id: 'beauty-3',
    name: 'Heated Eyelash Curler Pro',
    description: 'Electric heated eyelash curler with temperature control. USB rechargeable for perfect lashes anywhere.',
    price: 1999,
    originalPrice: 2999,
    image: '/images/beauty-3.jpg',
    category: 'beauty',
    subcategory: 'eye-tools',
    rating: 4.6,
    reviews: 456,
    inStock: true,
    isNew: true,
    colors: ['Rose Gold', 'White']
  },
  {
    id: 'beauty-4',
    name: '7-Color LED Face Mask',
    description: 'Professional LED light therapy mask with 7 colors for various skin concerns. Spa treatment at home.',
    price: 8999,
    originalPrice: 12999,
    image: '/images/beauty-4.jpg',
    category: 'beauty',
    subcategory: 'skincare-devices',
    rating: 4.8,
    reviews: 234,
    inStock: true,
    colors: ['White']
  },
  {
    id: 'beauty-5',
    name: 'Smart Pore Vacuum Cleaner',
    description: 'Electric blackhead remover with 5 suction levels and LCD display. Clear skin made easy.',
    price: 2999,
    originalPrice: 4499,
    image: '/images/beauty-5.jpg',
    category: 'beauty',
    subcategory: 'skincare-devices',
    rating: 4.5,
    reviews: 678,
    inStock: true,
    colors: ['White', 'Rose Gold']
  },
  {
    id: 'beauty-6',
    name: 'Ultrasonic Skin Scrubber',
    description: 'Deep cleansing spatula with ultrasonic technology for blackhead removal and skin exfoliation.',
    price: 2499,
    originalPrice: 3499,
    image: '/images/beauty-6.jpg',
    category: 'beauty',
    subcategory: 'skincare-devices',
    rating: 4.6,
    reviews: 345,
    inStock: true,
    isNew: true,
    colors: ['White']
  },
  {
    id: 'beauty-7',
    name: 'IPL Hair Removal Device',
    description: 'At-home IPL laser hair remover with 5 intensity levels. Permanent hair reduction technology.',
    price: 12999,
    originalPrice: 17999,
    image: '/images/beauty-7.jpg',
    category: 'beauty',
    subcategory: 'hair-removal',
    rating: 4.7,
    reviews: 189,
    inStock: true,
    colors: ['White', 'Rose Gold']
  },
  {
    id: 'beauty-8',
    name: 'Auto Makeup Brush Cleaner',
    description: 'Electric makeup brush cleaning and drying machine. Clean brushes in seconds, not hours.',
    price: 3999,
    originalPrice: 5499,
    image: '/images/beauty-8.jpg',
    category: 'beauty',
    subcategory: 'makeup-tools',
    rating: 4.8,
    reviews: 234,
    inStock: true,
    colors: ['Pink', 'White']
  },
  {
    id: 'beauty-9',
    name: 'Nano Ionic Facial Steamer',
    description: 'Professional facial steamer with nano-ionic technology. Opens pores for deep cleansing.',
    price: 3499,
    originalPrice: 4999,
    image: '/images/beauty-9.jpg',
    category: 'beauty',
    subcategory: 'skincare-devices',
    rating: 4.6,
    reviews: 412,
    inStock: true,
    colors: ['White']
  },
  {
    id: 'beauty-10',
    name: 'Jade Face Roller Massager',
    description: 'Electric jade face roller with microcurrent technology. Anti-aging facial massage device.',
    price: 2999,
    originalPrice: 3999,
    image: '/images/beauty-10.jpg',
    category: 'beauty',
    subcategory: 'skincare-devices',
    rating: 4.5,
    reviews: 567,
    inStock: true,
    colors: ['Rose Gold']
  },
  {
    id: 'beauty-11',
    name: 'Pro Hair Styling Kit',
    description: 'Professional hair dryer and straightener set with ionic technology. Salon results at home.',
    price: 6999,
    originalPrice: 9999,
    image: '/images/beauty-11.jpg',
    category: 'beauty',
    subcategory: 'hair-tools',
    rating: 4.8,
    reviews: 345,
    inStock: true,
    isBestseller: true,
    colors: ['Rose Gold', 'Black']
  },
  {
    id: 'beauty-12',
    name: 'Precision Eyebrow Trimmer',
    description: 'Electric eyebrow trimmer and razor set. Painless precision hair removal for perfect brows.',
    price: 1499,
    originalPrice: 2499,
    image: '/images/beauty-12.jpg',
    category: 'beauty',
    subcategory: 'hair-removal',
    rating: 4.6,
    reviews: 789,
    inStock: true,
    colors: ['White', 'Gold']
  },

  // ADDITIONAL DRESSES (16-20)
  {
    id: 'dress-16',
    name: 'Ruby Red Evening Gown',
    description: 'Stunning ruby red evening gown with off-shoulder design and flowing silk fabric. Perfect for gala events and red carpet moments.',
    price: 8999,
    originalPrice: 11999,
    image: '/images/dress-16.jpg',
    category: 'dress',
    subcategory: 'evening',
    rating: 4.9,
    reviews: 145,
    inStock: true,
    isNew: true,
    colors: ['Red', 'Burgundy', 'Black'],
    sizes: ['XS', 'S', 'M', 'L', 'XL']
  },
  {
    id: 'dress-17',
    name: 'Pastel Floral Chiffon Dress',
    description: 'Beautiful floral print summer dress in soft pastel colors. Flowing chiffon fabric with v-neckline, perfect for garden parties.',
    price: 3799,
    originalPrice: 4999,
    image: '/images/dress-17.jpg',
    category: 'dress',
    subcategory: 'casual',
    rating: 4.7,
    reviews: 234,
    inStock: true,
    colors: ['Pastel', 'Pink', 'Blue'],
    sizes: ['XS', 'S', 'M', 'L', 'XL']
  },
  {
    id: 'dress-18',
    name: 'Black Lace Cocktail Dress',
    description: 'Elegant black cocktail dress with intricate lace details. Short length design perfect for parties and evening events.',
    price: 4599,
    originalPrice: 5999,
    image: '/images/dress-18.jpg',
    category: 'dress',
    subcategory: 'party',
    rating: 4.8,
    reviews: 312,
    inStock: true,
    isBestseller: true,
    colors: ['Black', 'Navy'],
    sizes: ['XS', 'S', 'M', 'L', 'XL']
  },
  {
    id: 'dress-19',
    name: 'Royal Blue Anarkali Suit',
    description: 'Traditional Indian anarkali dress in royal blue with exquisite gold embroidery. Perfect for weddings and festive occasions.',
    price: 6999,
    originalPrice: 8999,
    image: '/images/dress-19.jpg',
    category: 'dress',
    subcategory: 'ethnic',
    rating: 4.9,
    reviews: 189,
    inStock: true,
    colors: ['Blue', 'Red', 'Green'],
    sizes: ['S', 'M', 'L', 'XL', 'XXL']
  },
  {
    id: 'dress-20',
    name: 'Classic White Shift Dress',
    description: 'Modern minimalist white shift dress, knee length design perfect for professional workwear and business meetings.',
    price: 2999,
    originalPrice: 3999,
    image: '/images/dress-20.jpg',
    category: 'dress',
    subcategory: 'workwear',
    rating: 4.6,
    reviews: 278,
    inStock: true,
    colors: ['White', 'Black', 'Navy'],
    sizes: ['XS', 'S', 'M', 'L', 'XL']
  },

  // ADDITIONAL JEWELRY (13-17)
  {
    id: 'jewelry-13',
    name: 'Gold Chain Pendant Necklace',
    description: 'Elegant gold chain necklace with beautiful pendant. Timeless piece that complements any outfit.',
    price: 5999,
    originalPrice: 7999,
    image: '/images/jewelry-13.jpg',
    category: 'jewelry',
    subcategory: 'necklace',
    rating: 4.7,
    reviews: 234,
    inStock: true,
    colors: ['Gold', 'Rose Gold']
  },
  {
    id: 'jewelry-14',
    name: 'Diamond Stud Earrings',
    description: 'Classic diamond stud earrings in white gold setting. Sparkling elegance for everyday wear or special occasions.',
    price: 14999,
    originalPrice: 19999,
    image: '/images/jewelry-14.jpg',
    category: 'jewelry',
    subcategory: 'earrings',
    rating: 4.9,
    reviews: 156,
    inStock: true,
    isBestseller: true,
    colors: ['White Gold', 'Yellow Gold']
  },
  {
    id: 'jewelry-15',
    name: 'Rose Gold Bangle Set',
    description: 'Beautiful rose gold bangle bracelet set with elegant design. Stack them or wear individually for versatile styling.',
    price: 6999,
    originalPrice: 8999,
    image: '/images/jewelry-15.jpg',
    category: 'jewelry',
    subcategory: 'bracelet',
    rating: 4.6,
    reviews: 198,
    inStock: true,
    isNew: true,
    colors: ['Rose Gold', 'Gold', 'Silver']
  },
  {
    id: 'jewelry-16',
    name: 'Sapphire Diamond Ring',
    description: 'Stunning sapphire ring with diamond halo in white gold band. A statement piece that captures attention.',
    price: 39999,
    originalPrice: 49999,
    image: '/images/jewelry-16.jpg',
    category: 'jewelry',
    subcategory: 'ring',
    rating: 4.9,
    reviews: 89,
    inStock: true,
    colors: ['White Gold', 'Platinum'],
    sizes: ['5', '6', '7', '8', '9']
  },
  {
    id: 'jewelry-17',
    name: 'Pearl Drop Earrings',
    description: 'Elegant pearl drop earrings with gold hooks. Classic design that adds sophistication to any ensemble.',
    price: 3499,
    originalPrice: 4499,
    image: '/images/jewelry-17.jpg',
    category: 'jewelry',
    subcategory: 'earrings',
    rating: 4.7,
    reviews: 267,
    inStock: true,
    colors: ['Gold', 'Silver']
  },

  // ADDITIONAL BEAUTY ELECTRONICS (13-17)
  {
    id: 'beauty-13',
    name: 'Professional Hair Straightener',
    description: 'Salon-quality ceramic hair straightener with temperature control. Rose gold design for beautiful, smooth hair.',
    price: 4999,
    originalPrice: 6999,
    image: '/images/beauty-13.jpg',
    category: 'beauty',
    subcategory: 'hair-tools',
    rating: 4.8,
    reviews: 456,
    inStock: true,
    isBestseller: true,
    colors: ['Rose Gold', 'Black']
  },
  {
    id: 'beauty-14',
    name: 'Sonic Facial Cleansing Brush',
    description: 'Electric sonic face cleanser with soft silicone bristles. Deep cleansing for radiant, healthy-looking skin.',
    price: 2999,
    originalPrice: 3999,
    image: '/images/beauty-14.jpg',
    category: 'beauty',
    subcategory: 'skincare-devices',
    rating: 4.7,
    reviews: 678,
    inStock: true,
    colors: ['Pink', 'White']
  },
  {
    id: 'beauty-15',
    name: 'Electric Makeup Brush Set',
    description: 'Professional electric makeup brush set with charging base. Rose gold handles for flawless makeup application.',
    price: 5999,
    originalPrice: 7999,
    image: '/images/beauty-15.jpg',
    category: 'beauty',
    subcategory: 'makeup-tools',
    rating: 4.6,
    reviews: 345,
    inStock: true,
    isNew: true,
    colors: ['Rose Gold']
  },
  {
    id: 'beauty-16',
    name: 'Microcurrent Face Lifting Device',
    description: 'Anti-aging microcurrent device for face lifting and toning. Professional results at home with regular use.',
    price: 7999,
    originalPrice: 9999,
    image: '/images/beauty-16.jpg',
    category: 'beauty',
    subcategory: 'skincare-devices',
    rating: 4.5,
    reviews: 234,
    inStock: true,
    colors: ['White', 'Gold']
  },
  {
    id: 'beauty-17',
    name: 'Electric Foot Callus Remover',
    description: 'Professional pedicure tool for removing hard skin and calluses. Rechargeable with multiple roller heads.',
    price: 1999,
    originalPrice: 2999,
    image: '/images/beauty-17.jpg',
    category: 'beauty',
    subcategory: 'foot-care',
    rating: 4.6,
    reviews: 567,
    inStock: true,
    colors: ['White', 'Pink']
  }
];

export const dressSubcategories = [
  { id: 'evening', name: 'Evening Wear', count: 4 },
  { id: 'workwear', name: 'Workwear', count: 3 },
  { id: 'cocktail', name: 'Cocktail', count: 2 },
  { id: 'casual', name: 'Casual', count: 3 },
  { id: 'party', name: 'Party Wear', count: 2 },
  { id: 'ethnic', name: 'Ethnic', count: 2 },
  { id: 'boho', name: 'Bohemian', count: 1 },
  { id: 'jumpsuit', name: 'Jumpsuits', count: 1 },
  { id: 'vintage', name: 'Vintage', count: 1 },
  { id: 'summer', name: 'Summer Collection', count: 1 }
];

export const categories = [
  {
    id: 'dress',
    name: 'Dresses',
    description: 'Modern & Elegant Styles',
    image: '/images/dress-3.jpg',
    bgColor: 'from-rose-50 to-rose-100',
    accentColor: '#ff6c79',
    itemCount: 20,
    subcategories: dressSubcategories
  },
  {
    id: 'jewelry',
    name: 'Jewelry',
    description: 'Luxury & Contemporary',
    image: '/images/jewelry-1.jpg',
    bgColor: 'from-orange-50 to-amber-100',
    accentColor: '#e8a87c',
    itemCount: 17,
    subcategories: [
      { id: 'necklace', name: 'Necklaces', count: 4 },
      { id: 'earrings', name: 'Earrings', count: 4 },
      { id: 'ring', name: 'Rings', count: 3 },
      { id: 'bracelet', name: 'Bracelets', count: 3 },
      { id: 'anklet', name: 'Anklets', count: 1 },
      { id: 'sets', name: 'Jewelry Sets', count: 2 }
    ]
  },
  {
    id: 'beauty',
    name: 'Beauty Electronics',
    description: 'Smart Beauty Tools from China',
    image: '/images/beauty-4.jpg',
    bgColor: 'from-purple-50 to-lavender-100',
    accentColor: '#c084fc',
    itemCount: 17,
    subcategories: [
      { id: 'nail-tools', name: 'Nail Care', count: 2 },
      { id: 'skincare-devices', name: 'Skincare', count: 4 },
      { id: 'hair-tools', name: 'Hair Care', count: 2 },
      { id: 'eye-tools', name: 'Eye Care', count: 1 },
      { id: 'makeup-tools', name: 'Makeup Tools', count: 2 },
      { id: 'hair-removal', name: 'Hair Removal', count: 2 },
      { id: 'foot-care', name: 'Foot Care', count: 1 },
      { id: 'massage', name: 'Massage', count: 3 }
    ]
  }
];

// Search suggestions based on popular searches
export const searchSuggestions = [
  'satin dress',
  'black evening dress',
  'diamond bracelet',
  'gold earrings',
  'nail drill',
  'LED face mask',
  'hair removal',
  'silk dress',
  'pearl necklace',
  'eyelash curler',
  'pore vacuum',
  'cocktail dress',
  'ring',
  'facial steamer',
  'bodycon dress'
];

export const getProductsByCategory = (category: string) => {
  return products.filter(product => product.category === category);
};

export const getProductById = (id: string) => {
  return products.find(product => product.id === id);
};

export const getNewArrivals = () => {
  return products.filter(product => product.isNew);
};

export const getBestsellers = () => {
  return products.filter(product => product.isBestseller);
};

export const getSaleItems = () => {
  return products.filter(product => product.originalPrice && product.originalPrice > product.price);
};

export const searchProducts = (query: string) => {
  const lowercaseQuery = query.toLowerCase();
  return products.filter(product => 
    product.name.toLowerCase().includes(lowercaseQuery) ||
    product.description.toLowerCase().includes(lowercaseQuery) ||
    product.subcategory.toLowerCase().includes(lowercaseQuery) ||
    product.category.toLowerCase().includes(lowercaseQuery)
  );
};

import { useState, Suspense, lazy } from 'react';
import { CartProvider } from '@/context/CartContext';
import { WishlistProvider } from '@/context/WishlistContext';
import { CategoryProvider } from '@/context/CategoryContext';
import { AuthProvider } from '@/context/AuthContext';
import { SearchProviderFixed } from '@/context/SearchContext';
import Navigation from '@/components/Navigation';
import CartDrawer from '@/components/CartDrawer';
import WishlistDrawer from '@/components/WishlistDrawer';
import ProductDetail from '@/components/ProductDetail';
import AuthModal from '@/components/AuthModal';
import ImageSearch from '@/components/ImageSearch';
import Hero from '@/sections/Hero';
import Categories from '@/sections/Categories';
import Products from '@/sections/Products';
import Features from '@/sections/Features';
import Newsletter from '@/sections/Newsletter';
import Footer from '@/sections/Footer';
import type { Product } from '@/data/products';
import './App.css';

function App() {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isImageSearchOpen, setIsImageSearchOpen] = useState(false);
  const [imageSearchResults, setImageSearchResults] = useState<Product[] | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isProductDetailOpen, setIsProductDetailOpen] = useState(false);

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    setIsProductDetailOpen(true);
  };

  const handleImageSearchResults = (results: Product[]) => {
    setImageSearchResults(results);
    // Scroll to products section
    document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <AuthProvider>
      <SearchProviderFixed>
        <CartProvider>
          <WishlistProvider>
            <CategoryProvider>
              <div className="min-h-screen bg-cream">
                {/* Navigation */}
                <Navigation
                  onCartClick={() => setIsCartOpen(true)}
                  onWishlistClick={() => setIsWishlistOpen(true)}
                  onAuthClick={() => setIsAuthOpen(true)}
                  onImageSearchClick={() => setIsImageSearchOpen(true)}
                />

                {/* Main Content */}
                <main>
                  {/* Hero Section */}
                  <Hero />

                  {/* Categories Section */}
                  <Categories />

                  {/* Products Section */}
                  <Products 
                    onProductClick={handleProductClick} 
                    imageSearchResults={imageSearchResults}
                  />

                  {/* Features Section */}
                  <Features />

                  {/* Newsletter Section */}
                  <Newsletter />
                </main>

                {/* Footer */}
                <Footer />

                {/* Drawers & Modals */}
                <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
                <WishlistDrawer isOpen={isWishlistOpen} onClose={() => setIsWishlistOpen(false)} />
                <ProductDetail
                  product={selectedProduct}
                  isOpen={isProductDetailOpen}
                  onClose={() => setIsProductDetailOpen(false)}
                />
                <AuthModal
                  isOpen={isAuthOpen}
                  onClose={() => setIsAuthOpen(false)}
                />
                <ImageSearch
                  isOpen={isImageSearchOpen}
                  onClose={() => setIsImageSearchOpen(false)}
                  onResults={handleImageSearchResults}
                />
              </div>
            </CategoryProvider>
          </WishlistProvider>
        </CartProvider>
      </SearchProviderFixed>
    </AuthProvider>
  );
}

export default App;
